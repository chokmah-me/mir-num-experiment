# JSA Paper Handover Dossier
## "Empirical Validation of the Compiler-as-NUM Hypothesis: A Shadow-Price Experiment with MIR"
### Target: Journal of Systems Architecture (Elsevier)
### Author: Daniyel Yaacov Bilar, Chokmah LLC, Vermont 05055

---

## 1. CURRENT STATE (What Exists)

### 1.1 Completed TACO-length draft (8 pages, ~3,150 words)
- **File**: `empirical-paper-draft.md` (in project files)
- Sections: Abstract, Introduction, Background & Method, Results, Discussion, Reproducibility, Conclusion, References
- All statistical claims grounded in actual experimental output
- Conservative claims throughout — standalone decision function limitation disclosed prominently

### 1.2 Experimental Results (v2, stratified)
All from actual pipeline runs. These numbers are final:

**Core Tests (all PASS):**
- Spearman ρ = 0.71 (pooled), 95% CI [0.67, 0.74], p = 1.07 × 10⁻¹¹⁴, n = 750
- Cohen's d = 2.00 (hot 66.7%, cold 0.0%)
- Agreement: 98.4% (738/750), 12 discordant pairs

**Opt-Level Stratification:**
- O0 (thresh=20): ρ = 0.50, CI [0.40, 0.59], p = 3.22 × 10⁻¹⁷, inline rate 20.0%
- O1 (thresh=50): ρ = 0.82, CI [0.77, 0.85], p = 4.25 × 10⁻⁶¹, inline rate 40.0%
- O2 (thresh=100): ρ = 0.82, CI [0.77, 0.85], p = 4.25 × 10⁻⁶¹, inline rate 40.0%
- Cross-level range: 0.32 (VARIABLE — O0 ceiling effect)

**Size Stratification (skewed, pooled across opt levels):**
- 10 IR: hot 100%, cold 0%, ρ=1.00 — decision boundary
- 50 IR: hot 100%, cold 0%, ρ=1.00 — decision boundary
- 100 IR: hot 66.7%, cold 0%, ρ=0.71 — decision boundary
- 200 IR: hot 66.7%, cold 0%, ρ=0.71 — decision boundary
- 500 IR: hot 0%, cold 0%, ρ=undefined — ceiling (never inlined)

**Descriptive Stats:**
- Baseline: 750 rows, 20.0% inline rate
- Uniform: 750 rows, 20.0% (confirms determinism)
- Skewed: 750 rows, 33.3%
- Perturbed: 750 rows, 34.9%

### 1.3 Raw Data
Four CSV files (750 rows each) in project files:
- `baseline_decisions.csv`
- `uniform_decisions.csv`
- `skewed_decisions.csv`
- `perturbed_decisions.csv`

Columns: `func_name, shadow_price, ir_count, opt_level, inlined, threshold_baseline, threshold_adjusted`

NOTE: The project CSVs are the v1 data (250 rows, no opt_level column). The v2 stratified data (750 rows, with opt_level) was generated on Daniyel's local machine. The numbers above come from his actual v2 pipeline output. The v2 source code is in the project as `src/test-num-experiment.c` (285 lines) and `src/analyze-num.py` (621 lines).

### 1.4 Companion Theory Paper
- **File**: `dyb2025ePAPERCompanionBilar2007bCompilerasNUMREL.pdf` (4 pages, in project files)
- Title: "The Compiler as a Decomposed Optimization System: Companion Paper to Bilar (2007)"
- Key content: Maps compiler architectures → NUM decomposition strategies (primal, dual, penalty, ADMM)
- Citation: Bilar, D. Y. (2025). Unpublished manuscript.

### 1.5 Experimental Code
All in `mir-num-experiment/` directory:
- `mir-patches/01-mir-h-shadow-price.patch` (9 lines) — adds shadow_price field to MIR_func
- `mir-patches/02-mir-gen-c-logging.patch` (50 lines) — adds logging + decision function
- `src/test-num-experiment.c` (285 lines) — v2 test harness with opt-level stratification
- `src/analyze-num.py` (621 lines) — v2 analysis with stratified analyses
- `scripts/build.ps1` (274 lines) — clone MIR, patch, compile (with fallback)
- `scripts/run-conditions.ps1` (85 lines) — run all 4 conditions
- `scripts/full-pipeline.ps1` (81 lines) — end-to-end

### 1.6 Blog Post
- `blog-post.md` — workshop-level writeup of v1 results, conservative claims

---

## 2. WHAT JSA REQUIRES (Gap Analysis)

JSA typical: 15–25 pages, comprehensive related work, figures, Elsevier format.
Current draft: ~8 pages, 5 references, no figures, no related work.

### Must Add (in priority order):

#### A. Related Work Section (2–3 pages, ~15 new references)
This is the biggest gap. Current paper cites only 5 works. JSA expects comprehensive coverage.

**Required literature clusters:**

1. **Compiler optimization as search/optimization:**
   - Cooper, Schielke, Subramanian (1999). Optimizing for reduced code space using genetic algorithms. LCTES.
   - Agakov et al. (2006). Using machine learning to focus iterative optimization. CGO.
   - Purini & Jain (2013). Finding good optimization sequences covering program space. TACO.

2. **Profile-guided optimization:**
   - Chang et al. (2019). AutoFDO: Automatic feedback-directed optimization for warehouse-scale applications. CGO.
   - Panchenko et al. (2019). BOLT: A practical binary optimizer for data centers. CGO.
   - Chen et al. (2016). AutoFDO: Feedback-directed optimization for production code.

3. **JIT compiler design and inlining:**
   - Paleczny, Vick, Click (2001). The Java HotSpot server compiler. JVM Research.
   - Gal et al. (2009). Trace-based JIT compilation for lazy functional languages. PPDP.
   - Arnold et al. (2000). Adaptive optimization in the Jalapeño JVM. OOPSLA.

4. **NUM and optimization theory in systems:**
   - Kelly, Maulloo, Tan (1998). Rate control for communication networks. JORS.
   - Low & Lapsley (1999). Optimization flow control. IEEE/ACM Trans. Networking.
   - Palomar & Chiang (2006). A tutorial on decomposition methods. IEEE Signal Processing.

5. **Lightweight JIT compilers:**
   - Context on MIR vs LuaJIT, Wasm3, QBE, etc.

**The next session must do web searches to find exact citations and verify these are correct/current.**

#### B. Figures (6 figures, ~3 pages)
None exist yet. Must generate from the v2 CSV data:

1. **Fig 1**: Shadow price vs inlining decision scatterplot (one panel per opt level) — shows decision boundary visually
2. **Fig 2**: Hot vs cold inlining rate bar chart with Cohen's d annotation
3. **Fig 3**: Inlining rate by function size (grouped bars: hot/cold at each size bucket)
4. **Fig 4**: Spearman ρ by optimization level (bar chart with CI error bars)
5. **Fig 5**: Perturbation robustness — 2×2 contingency visualization
6. **Fig 6**: MIR pipeline / NUM architecture diagram (conceptual, from theory paper)

The analyze-num.py already generates a 3×3 visualization grid as `num-analysis.png`. This can be decomposed into individual figures.

#### C. Expanded Background (split into 2 sections, +2 pages)
- Section 2: Background — add NUM formalism explanation (currently only cited), MIR comparison to other JITs, formalize U(x)
- Section 3: Experimental Method — current 2.3/2.4 become their own section

#### D. Expanded Discussion (+2 pages)
- Add 4.2: Comparison to existing JIT heuristics (HotSpot, V8 TurboFan cost models)
- Add 4.3: Expanded design implications
- Add 4.5: Detailed future work (hook into MIR_gen(), test register allocation, continuous shadow prices, real codebases)

#### E. Data Availability Statement (required by Elsevier)
Must include Zenodo DOI or GitHub URL. Daniyel needs to:
1. Create GitHub repo for mir-num-experiment
2. Upload to Zenodo and get DOI
3. Add statement to paper

#### F. Elsevier Formatting
JSA uses Elsevier article class. Template: `elsarticle.cls` with `elsarticle-num.bst` for references.
Download from: https://www.elsevier.com/researcher/author/policies-and-guidelines/latex-instructions

---

## 3. WHAT DOES NOT NEED TO CHANGE

- All statistical results are final — do not re-run experiments
- Abstract is good as-is (under 250 words)
- The standalone-function limitation framing is correct and well-calibrated
- Conservative claim structure is appropriate for JSA
- Reference [2] stays as "Unpublished manuscript" unless Daniyel submits it first

---

## 4. CRITICAL CONSTRAINTS

1. **Never overclaim.** We tested our own decision function, not MIR's native inliner. This is disclosed. Don't soften this.
2. **All numbers come from actual runs.** The v2 stratified output is the ground truth. Don't invent or round numbers.
3. **O0 ceiling effect is a feature, not a bug.** Frame it as: constrained feasible region compresses dual variable range. This is a NUM prediction confirmed.
4. **The 12 discordant pairs are real.** They came from noise-induced threshold crossings. All 12 are skewed-no → perturbed-yes (asymmetric, consistent with hot functions getting larger absolute noise).
5. **Theory paper is cited as [2] = Bilar 2025, Unpublished manuscript.** Do not change this citation.

---

## 5. SUGGESTED WORKFLOW FOR NEXT SESSION

1. **Start by reading**: `empirical-paper-draft.md`, `paper_strategy`, and the companion PDF (all in project files)
2. **Web search** for the ~15 related work citations to verify they exist and get exact bibliographic details
3. **Expand section by section** following the table in Section 2 above
4. **Generate figures** from the CSV data (or describe them precisely if no code execution)
5. **Format for Elsevier** using elsarticle template
6. **Final output**: Complete .md or .tex manuscript, 15–20 pages

---

## 6. KEY REFERENCES (for copy-paste)

[1] Bilar, D. Y. (2007). Callgraph properties of executables. AI Communications, 20(4), 253–268.

[2] Bilar, D. Y. (2025). The compiler as a decomposed optimization system: Companion paper to Bilar (2007). Unpublished manuscript.

[3] Chiang, M., Low, S. H., Calderbank, A. R., & Doyle, J. C. (2007). Layering as optimization decomposition: A mathematical theory of network architectures. Proceedings of the IEEE, 95(1), 255–312.

[4] Makarov, V. (2020). MIR: A lightweight JIT compiler project. https://github.com/vnmakarov/mir

[5] Baez, J. C., & Stay, M. (2009). Physics, topology, logic and computation: A Rosetta stone. In B. Coecke (Ed.), New Structures for Physics (pp. 95–172). Springer, Berlin, Heidelberg.

---

## 7. NUM THRESHOLD FORMULA (for reference)

```
adjusted_threshold = baseline_threshold(opt_level) × (λ / 100.0)
lambda_scale clamped to [0.1, 5.0]
adjusted_threshold clamped to [5, 1000]
inlined = 1 if ir_count < adjusted_threshold, else 0

Baseline thresholds: O0=20, O1=50, O2=100
Shadow prices: neutral=100, hot=1000, cold=10
Perturbed noise: hot ±200, cold ±5, clamped to [1, 2000]
RNG seed: 42
```

---

## 8. FILE MANIFEST

```
Project files (read-only, available in /mnt/project/):
  empirical-paper-draft.md          — Current 8-page TACO draft (THE BASE DOCUMENT)
  paper_strategy                    — Two-paper coordination plan
  dyb2025ePAPERCompanion...pdf      — Theory companion paper (4 pages)
  baseline_decisions.csv            — v1 data (250 rows, no opt_level)
  uniform_decisions.csv             — v1 data
  skewed_decisions.csv              — v1 data
  perturbed_decisions.csv           — v1 data

Generated outputs (from prior sessions):
  mir-num-experiment/src/test-num-experiment.c   — v2 harness (285 lines)
  mir-num-experiment/src/analyze-num.py          — v2 analysis (621 lines)
  mir-num-experiment/scripts/build.ps1           — Build script
  mir-num-experiment/scripts/run-conditions.ps1  — Run script
  mir-num-experiment/scripts/full-pipeline.ps1   — End-to-end
  mir-num-experiment/mir-patches/*.patch          — MIR patches
  blog-post.md                                   — Workshop-level writeup
```
