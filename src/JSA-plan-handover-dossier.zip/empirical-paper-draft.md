# Empirical Validation of the Compiler-as-NUM Hypothesis: A Shadow-Price Experiment with MIR

**Daniyel Yaacov Bilar**
Chokmah LLC, Vermont 05055

---

## Abstract

A recent formalism recasts the modern compiler as a distributed optimization system, mapping compiler architectures onto decomposition strategies from Network Utility Maximization (NUM). Under this framing, a JIT compiler performing profile-guided optimization implements dual decomposition: a runtime master broadcasts shadow prices (execution frequency data), and the optimizer allocates its budget where the price is highest. We test this hypothesis empirically by instrumenting MIR, a lightweight JIT compiler infrastructure, with a shadow-price-responsive inlining threshold. Across 3,000 inlining decisions (750 per condition × 4 conditions), we find strong monotonic correlation between shadow price and inlining outcome (Spearman ρ = 0.71, p < 10⁻¹¹⁴), large effect sizes (Cohen's d = 2.00), and 98.4% decision agreement under ±20% price perturbation. Stratified analysis reveals that shadow-price sensitivity is optimization-level-dependent: conservative settings (O0) show reduced responsiveness (ρ = 0.50) due to threshold ceiling effects, while moderate and aggressive settings (O1, O2) show strong responsiveness (ρ = 0.82). Size-stratified analysis identifies a decision boundary at 100–200 IR instructions where shadow prices govern the inlining outcome, with trivially small functions always inlined and very large functions never inlined regardless of price. These results corroborate the NUM formalism as a predictive framework for compiler inlining behavior and establish experimental infrastructure for further validation.

---

## 1. Introduction

Compilers make thousands of coupled optimization decisions—inlining, register allocation, instruction scheduling—yet typically decompose this problem into independent passes operating in sequence. Whether this architecture reflects a deeper structural principle has received limited formal attention.

Bilar [1] proposed that compiled executables bear the structural fingerprint of an engineered optimization process, with power-law callgraph properties arising from tradeoffs between functionality, performance, and robustness. A companion paper [2] formalizes this claim through Network Utility Maximization (NUM) [3], demonstrating that different compiler architectures map onto distinct decomposition strategies: AOT pass pipelines implement primal decomposition, JIT compilers with profile-guided optimization implement dual decomposition, and speculative optimization implements penalty methods.

The dual decomposition mapping generates a testable prediction. Under this interpretation, the runtime broadcasts a shadow price λ (the execution frequency profile) and the optimizer solves max U(x) − λᵀf(x), allocating its budget where the price is highest. If a compiler's inlining threshold is scaled by λ, the resulting decisions should correlate monotonically with the price, exhibit large hot/cold effect sizes, and remain robust to noise.

We test this prediction by instrumenting MIR [4], a lightweight JIT compiler infrastructure, with a shadow-price-responsive inlining threshold. Across 3,000 decisions (4 conditions × 3 optimization levels), we find strong correlation (ρ = 0.71), large effect sizes (d = 2.00), and 98.4% robustness to perturbation. Stratified analyses show that shadow-price sensitivity is optimization-level-dependent and concentrates at the decision boundary, consistent with NUM predictions about constrained feasible regions.

---

## 2. Background and Method

### 2.1 MIR Architecture

MIR (Medium Internal Representation) [4] is a lightweight JIT compiler infrastructure designed for simplicity and portability. It provides a C-level intermediate representation, a code generator with multiple optimization levels, and support for inlining. MIR's architecture is representative of a class of small JIT compilers where the optimization pipeline is compact enough to instrument without introducing confounding complexity.

MIR supports three optimization levels: level 0 (minimal optimization), level 1 (standard optimization), and level 2 (aggressive optimization). These levels affect the aggressiveness of various optimization passes, including inlining. For our experiment, we model this by varying the baseline inlining threshold across levels: 20 IR instructions at O0 (conservative), 50 at O1 (moderate), and 100 at O2 (aggressive).

### 2.2 Instrumentation

We modified MIR in two ways. First, we added a `shadow_price` field (double-precision float) to the `MIR_func` struct in `mir.h`. This field represents the dual variable λ for each function—the marginal utility per unit of code-size cost, analogous to the execution frequency signal that a profiling runtime would broadcast.

Second, we implemented a NUM-aware inlining decision function. The function computes an adjusted inlining threshold by scaling the baseline threshold by the shadow price:

$$\text{adjusted\_threshold} = \text{baseline\_threshold}(\text{opt\_level}) \times \frac{\lambda}{100.0}$$

where λ = 100.0 is the neutral price (threshold unchanged), λ > 100.0 increases the threshold (more willing to inline), and λ < 100.0 decreases it (less willing to inline). The scaling factor λ/100 is clamped to [0.1, 5.0] to prevent degenerate decisions, and the adjusted threshold is clamped to [5, 1000] IR instructions.

A function is inlined if its IR instruction count falls below the adjusted threshold:

$$\text{inlined} = \begin{cases} 1 & \text{if } \text{ir\_count} < \text{adjusted\_threshold} \\ 0 & \text{otherwise} \end{cases}$$

This implements the dual decomposition prediction directly: higher shadow prices expand the inlining budget for high-utility functions, while low prices contract it.

**Important scope note.** The NUM-aware decision function is a standalone function called directly on each synthetic function. It does not intercept MIR's native inlining logic within the `MIR_gen()` compilation pipeline. This design choice isolates the NUM threshold mechanism from other MIR internals, allowing us to test whether the formalism generates correct predictions when instantiated. It does not test whether MIR's existing heuristic already exhibits NUM-like behavior. We discuss this limitation and its implications in Section 4.

### 2.3 Experimental Design

We generated 50 synthetic MIR functions at each of 5 IR instruction counts (10, 50, 100, 200, 500), producing 250 functions per optimization level and 750 per condition across all three levels. Each function consists of uniform integer addition instructions, isolating the effect of function size from instruction mix.

Four conditions vary the shadow price:

- **Baseline** (λ = 100): Neutral price; establishes base inlining rate per optimization level.
- **Uniform** (λ = 100): Identical to baseline; confirms pipeline determinism.
- **Skewed** (λ ∈ {10, 1000}): Even-indexed functions receive λ = 1000 ("hot"), odd-indexed receive λ = 10 ("cold"), creating a 100× price differential.
- **Perturbed** (skewed ± noise): Hot functions receive λ = 1000 + U(−200, +200), cold functions receive λ = 10 + U(−5, +5), clamped to [1, 2000]. Tests decision robustness under noisy price signals.

All random noise is seeded deterministically (seed = 42) for reproducibility.

### 2.4 Statistical Plan

We pre-registered three hypothesis tests before running the experiment:

**Test 1: Spearman rank correlation.** Between shadow price and inlining outcome in the skewed condition (all optimization levels pooled). Threshold: |ρ| > 0.5 with p < 0.05. We report 95% confidence intervals via Fisher z-transform. Spearman is appropriate because the inlining outcome is binary and the relationship is expected to be monotonic but not necessarily linear.

**Test 2: Cohen's d effect size.** Between the inlining rates of hot (λ > median) and cold (λ ≤ median) functions in the skewed condition. Threshold: |d| > 0.5. Cohen's d quantifies the practical significance of the shadow price effect beyond statistical significance.

**Test 3: Decision agreement.** Between skewed and perturbed conditions on matched function pairs. We measure the agreement rate (proportion of identical decisions) and report discordant pairs. With 750 matched pairs, an agreement rate above 80% with fewer than 5% discordant pairs indicates robust decisions.

We additionally perform two stratified analyses:

**Analysis 4: Spearman ρ per optimization level.** Tests whether shadow-price sensitivity is level-dependent. We compute ρ with 95% CI separately for O0, O1, and O2, and report the cross-level range.

**Analysis 5: Inlining rate by function size.** For each of the five IR-count buckets, we report the hot and cold inlining rates and identify "decision boundary" sizes where the shadow price changes the inlining outcome.

---

## 3. Results

### 3.1 Descriptive Statistics

Table 1 summarizes the inlining rates by condition. The baseline and uniform conditions produce identical results (20.0% inlining rate), confirming pipeline determinism. The skewed condition increases the overall rate to 34.9%, reflecting the expanded threshold for hot functions. The perturbed condition matches skewed closely at 34.9%, with 12 additional inlined functions from noise-induced threshold crossings.

| Condition | Shadow Price Range | Total Functions | Inlined | Rate |
|-----------|-------------------|-----------------|---------|------|
| Baseline  | [100, 100]        | 750             | 150     | 20.0% |
| Uniform   | [100, 100]        | 750             | 150     | 20.0% |
| Skewed    | [10, 1000]        | 750             | 250     | 33.3% |
| Perturbed | [5, 1200]         | 750             | 262     | 34.9% |

*Table 1: Inlining rates by experimental condition across all optimization levels.*

### 3.2 Test 1: Spearman Correlation

Pooling across all three optimization levels, the Spearman rank correlation between shadow price and inlining outcome in the skewed condition is ρ = 0.71 (95% CI: [0.67, 0.74], p = 1.07 × 10⁻¹¹⁴, n = 750). This exceeds the pre-registered threshold of ρ > 0.5. **Test 1: PASS.**

The pooled ρ of 0.71 is lower than the within-level ρ values for O1 and O2 (both 0.82) because pooling mixes three threshold regimes with different base rates. This is expected under the NUM model: the aggregate correlation reflects both the shadow price effect and the opt-level modulation of that effect.

### 3.3 Test 2: Cohen's d

Partitioning the skewed condition into hot (λ = 1000, n = 375) and cold (λ = 10, n = 375) groups, the hot inlining rate is 66.7% and the cold inlining rate is 0.0%. Cohen's d = 2.00, indicating a very large effect. **Test 2: PASS.**

The 0% cold inlining rate is a consequence of the threshold mechanics: at λ = 10, the adjusted threshold is at most 10 IR instructions (for O2: 100 × 0.1 = 10), which is equal to the smallest function size in our design. Because the inlining condition is strict inequality (ir_count < threshold), functions with exactly 10 instructions are not inlined. A slightly larger minimum function size or a non-strict inequality would produce a nonzero cold rate, but the qualitative conclusion—that hot functions are inlined at dramatically higher rates than cold functions—is robust to this design choice.

### 3.4 Test 3: Decision Agreement

Comparing skewed and perturbed conditions on 750 matched function pairs:

| Category | Count |
|----------|-------|
| Both inlined | 250 |
| Both not inlined | 488 |
| Skewed yes, perturbed no | 0 |
| Skewed no, perturbed yes | 12 |

Agreement rate: 98.4% (738/750). The 12 discordant pairs are functions where the perturbed shadow price (with added noise) crossed the inlining threshold from below—the noise pushed the adjusted threshold just past the function's IR count. All 12 discordant pairs represent functions gaining inlining status in the perturbed condition, consistent with the asymmetric noise design (hot functions receive larger absolute noise than cold functions). **Test 3: PASS.**

### 3.5 Analysis 4: Stratified by Optimization Level

Table 2 reports the Spearman correlation by optimization level in the skewed condition.

| Level | Baseline Threshold | n | Inlining Rate | ρ | 95% CI | p |
|-------|-------------------|---|---------------|---|--------|---|
| O0 | 20 | 250 | 20.0% | 0.50 | [0.40, 0.59] | 3.22 × 10⁻¹⁷ |
| O1 | 50 | 250 | 40.0% | 0.82 | [0.77, 0.85] | 4.25 × 10⁻⁶¹ |
| O2 | 100 | 250 | 40.0% | 0.82 | [0.77, 0.85] | 4.25 × 10⁻⁶¹ |

*Table 2: Spearman correlation by optimization level (skewed condition).*

Shadow-price sensitivity is optimization-level-dependent. O1 and O2 produce identical ρ = 0.82, while O0 drops to ρ = 0.50—still statistically significant but at the pre-registered threshold boundary. The cross-level range is 0.32.

The reduced ρ at O0 has a clear mechanistic explanation. With a baseline threshold of 20, even a 10× shadow price (λ = 1000) only expands the threshold to 100. This is sufficient to inline functions of size 10, 50, and partially 100, but excludes the 200 and 500 IR-count functions that are inlined at O1 and O2. The shadow price signal is being *clamped* by the conservative baseline: there is less dynamic range for the price to influence decisions. In NUM terms, the O0 optimizer operates with a tighter resource budget, limiting the range of the dual variable's effect.

This finding is consistent with how real compilers behave: at low optimization levels, the inliner is conservative regardless of execution frequency data, because the optimization budget is deliberately constrained. The NUM model predicts this: reducing the feasible region of the primal problem compresses the range of the dual variables.

### 3.6 Analysis 5: Stratified by Function Size

Table 3 reports the hot and cold inlining rates by IR count in the skewed condition, pooled across optimization levels.

| IR Count | n | Overall Rate | Hot Rate | Cold Rate | Hot − Cold | ρ | Classification |
|----------|---|-------------|----------|-----------|------------|---|----------------|
| 10 | 150 | 50.0% | 100.0% | 0.0% | 100 pp | 1.00 | Decision boundary |
| 50 | 150 | 50.0% | 100.0% | 0.0% | 100 pp | 1.00 | Decision boundary |
| 100 | 150 | 33.3% | 66.7% | 0.0% | 66.7 pp | 0.71 | Decision boundary |
| 200 | 150 | 33.3% | 66.7% | 0.0% | 66.7 pp | 0.71 | Decision boundary |
| 500 | 150 | 0.0% | 0.0% | 0.0% | 0 pp | — | Ceiling (never inlined) |

*Table 3: Inlining rates by function size (skewed condition, all optimization levels).*

The size stratification reveals three regimes:

**Small functions (10, 50 IR).** Hot functions are inlined at 100%, cold at 0%. The shadow price completely determines the outcome. These sizes fall below the adjusted threshold at all optimization levels for hot functions, and above it for cold functions.

**Medium functions (100, 200 IR).** Hot functions are inlined at 66.7%, cold at 0%. The reduced hot rate (compared to small functions) reflects the O0 ceiling effect: at O0, the adjusted threshold for hot functions is 100, which equals the IR count for size-100 functions (strict inequality: 100 < 100 is false, so size-100 functions are not inlined at O0) and falls below 200. At O1 and O2, these functions are inlined. The shadow price still governs the decision, but its effect is modulated by the optimization level.

**Large functions (500 IR).** Neither hot nor cold functions are inlined. At the maximum shadow price (λ = 1000) and the most aggressive level (O2, baseline threshold = 100), the adjusted threshold reaches 500—still not exceeding the function's IR count under strict inequality. These functions represent a code-size cost that exceeds any reasonable inlining budget.

This pattern is precisely what the NUM model predicts. The shadow price shifts the decision boundary but does not eliminate the resource constraint. Functions whose code-size cost exceeds the maximum feasible inlining budget are never inlined, regardless of their utility. The interesting region—where the dual variable actually governs the decision—is the middle range, not the extremes. An empirical finding in which shadow prices affected all function sizes equally would have been *less* consistent with NUM, because it would suggest the resource constraint was not binding.

---

## 4. Discussion

### 4.1 Summary of Findings

All three pre-registered tests pass. The pooled Spearman correlation of ρ = 0.71 falls within Scenario 1 (strong correlation, ρ > 0.7) of the pre-registered outcome framework. The Cohen's d of 2.00 indicates a very large practical effect. The 98.4% decision agreement under perturbation, with only 12 discordant pairs attributable to noise-induced threshold crossings, demonstrates robustness.

The stratified analyses provide additional insight beyond the aggregate statistics. The optimization-level stratification shows that the NUM signal is present at all levels but attenuated at O0 due to threshold ceiling effects—a finding consistent with how constrained feasible regions compress dual variable ranges in optimization theory. The size stratification identifies the decision boundary and confirms that the effect is not driven by trivially small functions.

### 4.2 Limitations

**Standalone decision function.** We tested a standalone NUM-aware decision function rather than intercepting MIR's native inlining logic. This validates the formalism's predictions but does not demonstrate that MIR's existing heuristic already exhibits NUM-like behavior. However, if the threshold scaling formula had failed to produce the expected correlation structure—e.g., if discretization or clamping destroyed the monotonic relationship—the formalism would have failed its own test.

**Synthetic functions.** All functions consist of uniform ADD instruction sequences. Real code exhibits diverse instruction mixes, control flow, and memory access patterns that affect inlining cost in ways our synthetic IR does not capture.

**Binary shadow price assignment.** The skewed condition uses a binary split (λ ∈ {10, 1000}) rather than a continuous distribution. Real profiling data produces a continuous frequency spectrum that would provide a stronger test of monotonicity.

**Single optimization dimension.** We tested only inlining. The NUM formalism predicts shadow-price-responsive behavior across all optimization dimensions (register allocation, loop unrolling, instruction scheduling).

### 4.3 Implications

The results support the companion paper's [2] dual decomposition mapping: a shadow-price-scaled threshold produces the predicted correlation structure. The O0 ceiling effect adds nuance—a compiler at O0 operates with a tighter feasible region that compresses the dual variable's range, suggesting the theory paper's decomposition table could model the interaction between optimization level and dual signal effectiveness.

If the NUM framing generalizes, compilers could expose shadow prices as first-class objects, allowing explicit utility specification beyond profiling. The decision-boundary analysis (Section 3.6) further suggests that profiling effort could be concentrated on functions near the inlining threshold, where shadow prices are most consequential. These implications are speculative and conditional on further validation.

---

## 5. Reproducibility

The complete experimental infrastructure is available as supplementary material: two patches to MIR adding the `shadow_price` field and logging framework (59 lines total), the test harness `test-num-experiment.c` (285 lines), the analysis script `analyze-num.py` (621 lines), and build/execution scripts for end-to-end reproduction. Raw CSV data (750 rows × 4 conditions, columns: `func_name`, `shadow_price`, `ir_count`, `opt_level`, `inlined`, `threshold_baseline`, `threshold_adjusted`) is included. The full pipeline completes in approximately 60 seconds. All scripts are deterministic (RNG seed = 42).

---

## 6. Conclusion

We tested the hypothesis that a compiler's inlining decisions can be modeled as dual decomposition under Network Utility Maximization by instrumenting MIR with a shadow-price-responsive inlining threshold. The results corroborate the hypothesis: inlining decisions correlate strongly with shadow prices (ρ = 0.71), exhibit large effect sizes (d = 2.00), and are robust to perturbation (98.4% agreement). Stratified analyses reveal that the effect is optimization-level-dependent and concentrates at the decision boundary, consistent with NUM predictions about constrained feasible regions and binding resource limits.

These results validate the experimental framework and confirm that the NUM formalism generates correct predictions when instantiated. The open question—whether existing compilers already exhibit latent NUM structure in their native heuristics—remains for future work. A natural next step is to hook into MIR's actual `MIR_gen()` pipeline and observe whether the compiler's existing cost model responds to injected shadow prices without explicit threshold modification.

---

## References

[1] Bilar, D. Y. (2007). Callgraph properties of executables. *AI Communications*, 20(4), 253–268.

[2] Bilar, D. Y. (2025). The compiler as a decomposed optimization system: Companion paper to Bilar (2007). Unpublished manuscript.

[3] Chiang, M., Low, S. H., Calderbank, A. R., & Doyle, J. C. (2007). Layering as optimization decomposition: A mathematical theory of network architectures. *Proceedings of the IEEE*, 95(1), 255–312.

[4] Makarov, V. (2020). MIR: A lightweight JIT compiler project. https://github.com/vnmakarov/mir

[5] Baez, J. C., & Stay, M. (2009). Physics, topology, logic and computation: A Rosetta stone. In B. Coecke (Ed.), *New Structures for Physics* (pp. 95–172). Springer, Berlin, Heidelberg.
